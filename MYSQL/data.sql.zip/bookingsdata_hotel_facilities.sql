-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: localhost    Database: bookingsdata
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `hotel_facilities`
--

DROP TABLE IF EXISTS `hotel_facilities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hotel_facilities` (
  `hotel_facilities_id` int NOT NULL AUTO_INCREMENT,
  `hotel_data_id` int NOT NULL,
  `type` text NOT NULL,
  `description` varchar(300) NOT NULL,
  PRIMARY KEY (`hotel_facilities_id`)
) ENGINE=InnoDB AUTO_INCREMENT=210 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hotel_facilities`
--

LOCK TABLES `hotel_facilities` WRITE;
/*!40000 ALTER TABLE `hotel_facilities` DISABLE KEYS */;
INSERT INTO `hotel_facilities` VALUES (193,12,'Pets',''),(194,12,'Food & Drink','Coffee house on site#Fruits#Wine/champagne#Breakfast in the room#Bar#Restaurant#'),(195,12,'Internet',''),(196,12,'Parking','Accessible parking#Parking garage#'),(197,12,'Reception services','Invoice provided#Lockers#Concierge service#Luggage storage#Tour desk#24-hour front desk#'),(198,12,'Cleaning services','Daily housekeeping#Trouser press#Ironing service#Dry cleaning#Laundry#'),(199,12,'Business facilities','Fax/photocopying#Business centre#Meeting/banquet facilities#'),(200,12,'Safety & security','Fire extinguishers#CCTV outside property#CCTV in common areas#Smoke alarms#Security alarm#24-hour security#Safety deposit box#'),(201,12,'General','Air conditioning#Non-smoking throughout#Heating#Car hire#Packed lunches#Lift#Family rooms#Facilities for disabled guests#Non-smoking rooms#Room service#'),(202,12,'Accessibility','Wheelchair accessible#'),(203,12,'Wellness facilities','Fitness#Fitness centre#'),(204,12,'Languages spoken','English#Spanish#'),(205,12,'What\'s nearby','Bergdorf Goodman#Wollman Rink#Trump Tower#Carnegie Hall#Central Park Zoo#New Amsterdam Theatre#Museum of Modern Art#'),(206,12,'Restaurants & cafes','Sarabeth\'s#'),(207,12,'Top attractions','Central Park#Rockefeller Center#Times Square#Grand Central Station#Metropolitan Museum of Art#Empire State Building#Madison Square Garden#Yankee Stadium#Ellis Island#Statue of Liberty#'),(208,12,'Public transport','57th Street IND Sixth Avenue Line#Fifth Avenue BMT Broadway Line#57th Street - Midtown#'),(209,12,'Closest airports','LaGuardia Airport#Teterboro#Newark Liberty International Airport#');
/*!40000 ALTER TABLE `hotel_facilities` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-30 19:41:54
