-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: localhost    Database: bookingsdata
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `hotel_data`
--

DROP TABLE IF EXISTS `hotel_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hotel_data` (
  `hotel_id` int NOT NULL AUTO_INCREMENT,
  `query_id` int NOT NULL,
  `name` text NOT NULL,
  `description` varchar(1000) NOT NULL,
  `address` varchar(200) NOT NULL,
  `rating` float NOT NULL,
  `total_reviews` int NOT NULL,
  `reason_to_choose` varchar(300) NOT NULL,
  `facilities` varchar(150) NOT NULL,
  `staff_rating` float NOT NULL,
  `facilities_rating` float NOT NULL,
  `cleaning_rating` float NOT NULL,
  `comfort_rating` float NOT NULL,
  `value_for_money_rating` float NOT NULL,
  `location_rating` float NOT NULL,
  `free_wifi_rating` float NOT NULL,
  `food_type` varchar(200) NOT NULL,
  PRIMARY KEY (`hotel_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hotel_data`
--

LOCK TABLES `hotel_data` WRITE;
/*!40000 ALTER TABLE `hotel_data` DISABLE KEYS */;
INSERT INTO `hotel_data` VALUES (12,3,'\nPark Lane New York\n','You\'re eligible for a Genius discount at Park Lane New York! To save at this property, all you have to do is .Park Lane New York is a deluxe hotel with a European ambiance, providing views over Central Park and the New York skyline. It is only 2 minutes’ walk from the elegant shops of 5th Avenue and the 59th Street N,Q,R underground station.Spacious and bright, rooms at Park Lane New York are fitted with oversized windows and fine linens. Amenities include flat-screen TVs and access to the on-site fitness centre.Enjoy a seasonal menu created by Joseph Fontanals at The Park Room Restaurant, or select from a wide variety of cocktails at Harry\'s New York Bar.New York’s Museum of Modern Art, Radio City Music Hall, and Rockefeller Center, are all within 10 minutes\' walk. With the park directly in front of the hotel, jogging and recreational activities are easily accessible. ','\n36 Central Park South, New York, NY 10019, United States\n',8.3,311,'\nBooking is safe\n\nManage your bookings online\n\nThe staff speak English\n\nGreat location and facilities for couples\n','Free WiFi#Parking#Family rooms#Non-smoking rooms#Fitness centre#Pets allowed#Bar#',8.8,8.2,8.8,8.9,7.6,9.7,6.7,'\nAmerican\n');
/*!40000 ALTER TABLE `hotel_data` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-30 19:41:55
